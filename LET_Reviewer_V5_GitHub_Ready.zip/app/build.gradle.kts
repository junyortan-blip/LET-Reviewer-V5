plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.letreviewer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.letreviewer"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "5.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
